let name="Harshitha"
let school_name="Z.P.H.S GLS(form)"
let grade="A+"
let maths_score=68;
let telugu_score=98;
let social_score=82;
console.log(name)
console.log(school_name);
console.log(grade)
console.log("maths",+maths_score)
console.log("telugu",+telugu_score)
console.log("social",+social_score)
