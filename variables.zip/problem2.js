let name="Harshitha";
let age=20;
console.log(name,age)
console.log(typeof(name),typeof(age))