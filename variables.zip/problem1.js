let name="Harshitha"
console.log(name)
name="Raghupathi Reddy"
console.log(name)
name="Nirmala"
console.log(name)
